#ifndef DECLARATIONS_H_
#define DECLARATIONS_H_

	void part1();
	void part1_basket(double, int []);
	int part1_menu();
	void part1_checkout(double, int []);


	void part2();
	int date_generator();
	void part2_basket(double, int []);
	int part2_menu();
	void part2_checkout(double, int []);



	void part3();
	double total_calculator(int []);
	void part3_basket(double, int []);
	int part3_menu();
	void part3_checkout(double, int []);


#endif /* DECLARATIONS_H_ */
